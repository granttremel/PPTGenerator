from distutils.core import setup
setup(name='PPTGenerator',
      description='Generate powerpoints from cosmx image files',
      author='Grant Tremel',
      author_email='gtremel@nanostring.com',
      version='1.0',
      packages = ['PPTGenerator']      
#py_modules=['ppt','cosmx_strings','util'],
      )